create SCHEMA projectap;
CREATE TABLE Traveler_info
(
PassportID INT (20)  NOT NULL,
firstName  VARCHAR(20),
lastName  VARCHAR(20),
phoneNo VARCHAR (10),
email varchar (10),
password INT (8),
CONSTRAINT Travler_info__PK PRIMARY KEY (PassportID)
);
create table TripInfo(
city varchar(10),
budget int(20),
duration int(10),
cityCode int(4) not null,
PTripID int (10),
constraint CityCode_PK primary key (cityCode),
constraint PTripID_FK foreign key (PTripID) references Traveler_info (PassportID)
);
CREATE TABLE categories
(
categoryID    int(5) not null,
CName   varchar(20),  
constraint Categories_PK  primary key (categoryID)
);
insert into projectap.categories(categoryID,CName)
values ('1','Hotel');
insert into projectap.categories(categoryID,CName)
values ('2','Resturants');
insert into projectap.categories(categoryID,CName)
values ('3','Tourist Destinations');

CREATE TABLE places
(
placeID    int(5) not null,
PName   varchar(20), 
CID     int(5),
cityCode int(10),
price decimal(6,2), 
constraint Places_PK  primary key (placeID),
constraint Places_fk1 foreign key (CID) references categories(categoryID) on delete cascade,
constraint Places_fk2 foreign key (cityCode) references TripInfo(cityCode) on delete cascade 
);
SET FOREIGN_KEY_CHECKS=0;
/* Hotel */
/* Dubai */
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (112095,'Raffles The Palm',1,2095,1149);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (122095,'Centara Mirage',1,2095,587);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (132095,'JA Beach Hotel',1,2095,715);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (142095,'Waldorf Astoria',1,2095,827);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (152095,'Jumeirah Al Naseem',1,2095,2196);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (162095,'Atlantis The Royal',1,2095,9000);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (172095,'Jumeirah Al Qasr',1,2095,1583);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (182095,'Mandarin Oriental',1,2095,2620);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (192095,'Atlantis, The Palm',1,2095,2226);
/* Jeddah */
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (114956,'Jeddah Hilton',1,4956,881);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (124956,'Andalus Habitat',1,4956,500);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (134956,'InterContinental',1,4956,954);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (144956,'SAS Hotel',1,4956,539);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (154956,'Ewaa Express Hotel',1,4956,520);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (164956,'WA Hotel',1,4956,690);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (174956,'Radisson Blu Hotel',1,4956,810);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (184956,'Moments Hotel',1,4956,285);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (194956,'Narcissus Hotel',1,4956,824);
/* Paris */
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (118312,'Hotel Eiffel Seine',1,8312,714);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (128312,'Le Parisis',1,8312,824);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (138312,'Provinces Opera',1,8312,507);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (148312,'Hotel Cluny Square',1,8312,402);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (158312,'Hotel Victoria',1,8312,487);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (168312,'Opera Maintenon',1,8312,568);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (178312,'Nation Montmartre',1,8312,568);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (188312,'Hotel Gramont',1,8312,1015);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (198312,'Apollinaire',1,8312,564);
/* Tokyo */
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (117608,'Keikyu Ex Inn',1,7608,565);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (127608,'Graphy Nezu',1,7608,432);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (137608,'Tokyo Prince',1,7608,783);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (147608,'Park Tower',1,7608,1720);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (157608,'JAL City',1,7608,450);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (167608,'By Shiomi Prince',1,7608,1039);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (177608,'Comfort Suites',1,7608,568);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (187608,'Hearton Hotel',1,7608,303);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (197608,'Hotel Kabuki',1,7608,950);
/* Seoul */
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (119504,'Sotetsu Hotel',1,9504,326);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (129504,'The Stay Classic',1,9504,490);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (139504,'Seoul Station',1,9504,679);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (149504,'Shilla Stay',1,9504,720);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (159504,'PJ Myeongdong',1,9504,382);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (169504,'Lotte City',1,9504,540);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (179504,'Royal Square',1,9504,234);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (189504,'Staz Hotel',1,9504,266);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (199504,'Koreana Hotel',1,9504,318);

/* Resturants */
/* Dubai */
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (212095,'RHAIN Restaurant',2,2095,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (222095,'DoorsDubai',2,2095,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (232095,'NAZCAA',2,2095,300);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (242095,'AWTAR',2,2095,100);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (252095,'AYAMNA',2,2095,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (262095,'QD’s',2,2095,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (272095,'Al MANDALOUN',2,2095,500);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (282095,'Kitchen6',2,2095,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (292095,'Amaseena',2,2095,150);
/* Jeddah */
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (214956,'Kiaora',2,4956,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (224956,'Mataam Al-Sharq',2,4956,100);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (234956,'Al-baik',2,4956,100);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (244956,'cheesecake factory ',2,4956,100);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (254956,'khayal Restaurant',2,4956,100);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (264956,'Piatto',2,4956,100);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (274956,'Nanod’s',2,4956,100);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (284956,'Knoak restaurant',2,4956,100);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (294956,'Sultan’s Steakhouse',2,4956,200);
/* Paris */
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (218312,'To Restaurant Paris',2,8312,500);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (228312,'ASPIC',2,8312,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (238312,'Le Trumilou',2,8312,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (248312,'Benoit Paris',2,8312,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (258312,'Restaurant L’Ange 20',2,8312,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (268312,'La Table de Colette',2,8312,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (278312,'Joséphine Chez',2,8312,300);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (288312,'Restaurant H',2,8312,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (298312,'Boutary',2,8312,200);
/* Tokyo */
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (217608,'Ise Sueyoshi',2,7608,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (227608,'Den',2,7608,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (237608,'NOBU Tokyo',2,7608,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (247608,'Tapas Molecular',2,7608,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (257608,'Toufuya Ukai',2,7608,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (267608,'Ryuzu',2,7608,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (277608,'LIKE',2,7608,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (287608,'MAZ',2,7608,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (297608,'plate tokyo',2,7608,150);
/* Seoul */
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (219504,'Joo Ok Restaurant',2,9504,300);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (229504,'Mingles',2,9504,100);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (239504,'MOSU Seoul',2,9504,100);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (249504,'Jungsik Seoul',2,9504,100);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (259504,'Seoul’n’Soul',2,9504,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (269504,'MUGUNGHWA',2,9504,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (279504,'Zero Complex',2,9504,50);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (289504,'N.Grill',2,9504,100);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (299504,'La Yeon',2,9504,50);

/* Tourist Destinations */
/* Dubai */
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (312095,'Burj Khalifa',3,2095,300);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (322095,'Emirates Towers',3,2095,250);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (332095,'Burj Al Arab',3,2095,300);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (342095,'Ski Dubai',3,2095,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (352095,'Dubai Creek',3,2095,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (362095,'Jumeirah Beach',3,2095,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (372095,'Dubai Dolphinarium',3,2095,500);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (382095,'Dolphin Bay',3,2095,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (392095,'Dubai Marina',3,2095,150);
/* Jeddah */
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (314956,'Jeddah Corniche',3,4956,50);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (324956,'Jeddah Boulevard',3,4956,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (334956,'Al Shallal Park',3,4956,100);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (344956,'Mall of Arabia',3,4956,50);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (354956,'Fakih Aquarium',3,4956,50);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (364956,'Gate of Mecca',3,4956,50);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (374956,'Syrian Market',3,4956,50);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (384956,'Floating Mosque',3,4956,50);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (394956,'Sultan’s Steakhouse',3,4956,50);
/* Paris */
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (318312,'Eiffel Tower',3,8312,500);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (328312,'Louvre Museum',3,8312,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (338312,'Cruise on the Seine',3,8312,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (348312,'Montmartre',3,8312,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (358312,'Palace of Versailles',3,8312,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (368312,'The Latin Quarter',3,8312,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (378312,'Luxembourg park',3,8312,300);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (388312,'Moulin Rouge',3,8312,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (398312,'Disneyland Paris',3,8312,200);
/* Tokyo */
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (317608,'Akihabara',3,7608,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (327608,'Tokyo Tower',3,7608,250);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (337608,'Shinjuku Gyoen ',3,7608,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (347608,'Meiji Shrine',3,7608,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (357608,'Ueno Park',3,7608,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (367608,'Tsukiji Market',3,7608,50);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (377608,'Sensoji Temple',3,7608,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (387608,'Imperial Palace',3,7608,250);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (397608,'Shibuya Pedestrian',3,7608,150);
/* Seoul */
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (319504,' Lotte World Seoul',3,9504,300);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (329504,'Hongdae Street ',3,9504,50);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (339504,'Nami Island',3,9504,300);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (349504,'Namsan Seoul Tower',3,9504,200);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (359504,'Bukchon Village',3,9504,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (369504,'Ewha University',3,9504,150);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (379504,'Ewha Shopping Street',3,9504,50);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (389504,'Everland',3,9504,100);
insert into projectap.places(placeID,PName,CID,cityCode,price)
values (399504,'Myeongdong Street',3,9504,50);
CREATE TABLE Budget_Calculation 
(
PBudget_ID INT (20) ,
OBudget  VARCHAR(20),
NBudget  VARCHAR(20),                                                                                                     
constraint PBudget_ID_FK foreign key (PBudget_ID) references Traveler_info (PassportID)
);
